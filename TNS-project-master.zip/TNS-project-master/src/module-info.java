/**
 * 
 */
/**
 * 
 */
module FoodDeliveray {
	requires java.desktop;
	requires jdk.internal.le;
}