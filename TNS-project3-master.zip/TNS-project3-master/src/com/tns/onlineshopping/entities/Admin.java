package com.tns.onlineshopping.entities;

	public class Admin extends User {
	    public Admin(int userId, String username, String email) {
	        super(userId, username, email);
	    }
	}

